import React from "react";
import CardTopo from "./CardTopo";
import styled from "styled-components";

const Section = styled.section`
  background-color: #fff;
  height: 100%;
`;

const P = styled.p`
  color: blue;
  font-size: 12px;
`;

const Cards = ({ id, texto, destaqueTexto }) => {
  return (
    <>
      <Section id={id}>
        <CardTopo texto={texto} destaqueTexto={destaqueTexto} />
        <P>
          Lorem ipsum, dolor sit amet consectetur adipisicing elit. Inventore
          quae architecto eligendi libero aut voluptates voluptatibus veniam
          necessitatibus accusamus, omnis accusantium, quo repellat vero
          blanditiis rerum officiis est perspiciatis neque!
        </P>
      </Section>
    </>
  );
};

export default Cards;
