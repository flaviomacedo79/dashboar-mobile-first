import React from "react";
import CardTopo from "./CardTopo";
import styled from "styled-components";

const Section = styled.section`
  // background-color: #fff;
  background: #ffff00;
  height: 100%;
`;

const Div = styled.p`
  color: blue;
  font-size: 0.75rem;
  padding: 0 10px;
`;

const Estrutura = styled.div`
  width: 50%;
  height: auto;
  border-right: 1px solid #cccccc;
  position: relative;
`;

const EstruturaBefore = styled.div`
  &:after {
    content: " 🦄";
    right: -8px;
    top: 40%;
    position: absolute;
  }
`;

const CardDestaque = ({ id, texto, destaqueTexto }) => {
  return (
    <>
      <Section id={id}>
        <CardTopo texto={texto} destaqueTexto={destaqueTexto} />
        <Div>
          <Estrutura>
            <EstruturaBefore></EstruturaBefore>
            Lorem ipsum, dolor sit amet consectetur adipisicing elit. Inventore
            quae architecto eligendi libero aut voluptates voluptatibus veniam
            necessitatibus accusamus, omnis accusantium, quo repellat vero
            blanditiis rerum officiis est perspiciatis neque!
          </Estrutura>
          <Estrutura>
            <EstruturaBefore></EstruturaBefore>
            Lorem ipsum, dolor sit amet consectetur adipisicing elit. Inventore
            quae architecto eligendi libero aut voluptates voluptatibus veniam
            necessitatibus accusamus, omnis accusantium, quo repellat vero
            blanditiis rerum officiis est perspiciatis neque!
          </Estrutura>
          <Estrutura>
            <EstruturaBefore></EstruturaBefore>
            Lorem ipsum, dolor sit amet consectetur adipisicing elit. Inventore
            quae architecto eligendi libero aut voluptates voluptatibus veniam
            necessitatibus accusamus, omnis accusantium, quo repellat vero
            blanditiis rerum officiis est perspiciatis neque!
          </Estrutura>
          <Estrutura>
            <EstruturaBefore></EstruturaBefore>
            Lorem ipsum, dolor sit amet consectetur adipisicing elit. Inventore
            quae architecto eligendi libero aut voluptates voluptatibus veniam
            necessitatibus accusamus, omnis accusantium, quo repellat vero
            blanditiis rerum officiis est perspiciatis neque!
          </Estrutura>
          <Estrutura>
            <EstruturaBefore></EstruturaBefore>
            Lorem ipsum, dolor sit amet consectetur adipisicing elit. Inventore
            quae architecto eligendi libero aut voluptates voluptatibus veniam
            necessitatibus accusamus, omnis accusantium, quo repellat vero
            blanditiis rerum officiis est perspiciatis neque!
          </Estrutura>
        </Div>
      </Section>
    </>
  );
};

export default CardDestaque;
