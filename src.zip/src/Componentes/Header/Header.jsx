import React from "react";

const Header = () => {
  return <div>Teste de Header</div>;
};

export default Header;
