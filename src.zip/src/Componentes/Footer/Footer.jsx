import React from "react";

const Footer = () => {
  return <div>Teste Footer</div>;
};

export default Footer;
